import java.io.*;
import java.util.Scanner;

/**
 * This class will convert all our data from a text document containing all the data from the following website
 * into a csv file using string regexs
 * @author Ben Bastianelli StudentID :23368071
 * @Version 1.0
 */
public class TxtToCSV {

    public static void writeToCSV() {
        File inputFile = new File("Extracted_PDF_Content.txt");
        File outputCSV = new File("Occupations.csv");

        // Declare the headers for the CSV file
        String[] headers = {"Occupation", "Job Title", "Point", "Salary"};

        // Initialize Scanner for reading the input file
        try (Scanner in = new Scanner(inputFile);
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputCSV))) {

            // Write the header row to the CSV file
            writer.write(String.join(",", headers));
            writer.newLine();

            // Variables to hold current occupation and job title
            String currentOccupation = "";
            String currentJobTitle = "";

            // Loop through the lines in the text file
            while (in.hasNextLine()) {
                String line = in.nextLine().trim();

                // If the line contains an occupation (starts with "*")
                if (line.startsWith("*")) {
                    currentOccupation = line.substring(1).trim();  // Remove "*" and trim spaces
                }
                // If the line contains a job title (starts with "-")
                else if (line.startsWith("-")) {
                    currentJobTitle = line.substring(1).trim();  // Remove "-" and trim spaces
                }
                // If the line contains salaries or point values
                else if (!line.isEmpty()) {
                    // Split the line by whitespace, which separates point values and salaries
                    String[] values = line.split("\\s+");

                    // If there are point values and corresponding salaries
                    if (values.length > 0) {
                        // Ensure the values alternate between point and salary
                        for (int i = 0; i < values.length / 2; i++) {
                            String pointValue = values[i];
                            String salary = values[i + values.length / 2];

                            // Wrap the salary in double quotes to avoid issues with commas in the salary
                            salary = "\"" + salary + "\"";

                            // Create a CSV row with occupation, job title, point, and salary
                            String csvLine = String.join(",",
                                    currentOccupation,
                                    currentJobTitle,
                                    pointValue,
                                    salary);
                            writer.write(csvLine);
                            writer.newLine();
                        }
                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        writeToCSV();
    }
}
