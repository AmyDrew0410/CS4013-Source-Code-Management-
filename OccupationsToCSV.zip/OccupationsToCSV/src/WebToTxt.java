import java.io.*;
import java.net.*;
import java.nio.file.*;

public class WebToTxt {

    public static URL createLink() {
        try {
            URI websiteToURL = new URI("https://www.ul.ie/media/50283/download?inline");
            return websiteToURL.toURL();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static void downloadPDF(URL url, File outputFile) throws IOException {
        try (InputStream in = url.openStream()) {
            Files.copy(in, outputFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        }
    }

    public static String extractTextFromPDFWithPoppler(File pdfFile) throws IOException {
        File outputTxt = new File("Extracted_PDF_Content.txt");

        // Run the `pdftotext` command
        ProcessBuilder processBuilder = new ProcessBuilder("pdftotext", pdfFile.getAbsolutePath(), outputTxt.getAbsolutePath());
        Process process = processBuilder.start();

        try {
            process.waitFor();  // Wait for the process to complete
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Read the content of the generated text file
        return new String(Files.readAllBytes(outputTxt.toPath()));
    }

    public static void main(String[] args) {
        URL url = createLink();
        File pdfFile = new File("downloaded.pdf");

        try {
            // Download the PDF
            downloadPDF(url, pdfFile);

            // Extract text using pdftotext
            String pdfContent = extractTextFromPDFWithPoppler(pdfFile);

            // Output the extracted text
            System.out.println("Extracted PDF Content:\n" + pdfContent);
        } catch (IOException e) {
            throw new RuntimeException("An error occurred while processing the PDF.", e);
        }
    }
}
