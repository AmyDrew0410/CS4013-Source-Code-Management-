import Login.CLI;

import java.io.IOException;

public class MainMenu {
    public void run() throws IOException {
        CLI cli = new CLI();
        cli.login();
    }
}
