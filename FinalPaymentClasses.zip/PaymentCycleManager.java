package PaymentProcess;

import FileHandler.CSVReader;
import UserType.Employee;
import UserType.Employees;
import UserType.UserTypes;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class PaymentCycleManager {
    private Employees employees; //List of all employees
    private PayslipHistory payslipHistory; //Central history of payslips

    public PaymentCycleManager() throws FileNotFoundException {
        this.employees = new Employees();
        this.payslipHistory = new PayslipHistory();
    }

    /**
     * Method to check if the date is the 25th and if it is, generate payslips for all employees
     * in the list of employees of type userType.
     */
    public void processCycle(String month,int currentYear,LocalDate currentDate) throws IOException {
        boolean process = currentDate.getDayOfMonth() == 25;
        //Check if today is the 25th
        if(process){
            System.out.println("Today is the 25th. Generating payslips...");

            PayslipHistory history = new PayslipHistory();
            //Loop through all employees and generate payslips
            for(UserTypes employee : employees.getListOfEmployees()){
                PaymentProcess paymentProcess = new PaymentProcess((Double) employee.getSalary(), currentDate, employee.getMarital_Status(), employee.getUnionFees());

                //Create Payslip object and add it to the payslip history
                Payslip payslip = new Payslip(employee, paymentProcess, payslipHistory);

                history.addPayslip(payslip);
                //Save payslip to CSV


            }
        }else{
            System.out.println("Today is not the 25th. No payroll processing required.");
        }
        if(process) {
            Scanner in = new Scanner(System.in);
            payslipHistory.payslipToCSV(String.format("%d%s",currentYear,month));
        }

    }
}
