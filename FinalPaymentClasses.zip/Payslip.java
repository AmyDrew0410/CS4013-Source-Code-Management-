package PaymentProcess;

import FileHandler.*;
import UserType.UserTypes;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

import static java.lang.String.format;

/**
 * this class is to generate a payslip using the userTypes and payment process classes
 * as object types.
 * author : Amy Drew
 * student ID : 23370076
 */

public class Payslip {
    private final PaymentProcess paymentProcess;
    private final UserTypes employee;

    //Constructor to build payslip object from the payment process class and type and employee class and type
    public Payslip(UserTypes employee, PaymentProcess paymentProcess){
        this.employee = employee;
        this.paymentProcess = paymentProcess;
    }

    /**
     * Getter method to return the payslip object in the payment process type
     */
    public PaymentProcess getPaymentProcess(){
        return paymentProcess;
    }

    /**
     * getter methods to get different parts of the UserType.UserTypes class to then utilise in the structure of the payslip
     */
    public UserTypes getEmployee(){
        return employee;
    }

    public int getEmployeeID(){
        return getEmployee().getEmployee_ID();
    }

    public String getFirstName(){
        return getEmployee().getFirst_Name();
    }

    public String getLastName(){
        return getEmployee().getLast_Name();
    }

    public String getPPSNumber(){
        return getEmployee().getPPSN();
    }

    public LocalDate getDateOfPayslip(){
        return getPaymentProcess().getDateOfProcess();
    }

    /**
     * toString() method to use string builder to construct the payslip and
     * print it as a string.
     * @return this method returns a string
     */

    public String toString() {

        return String.join(", ", String.valueOf(getEmployeeID()), getFirstName(), getLastName(), getPPSNumber(), getDateOfPayslip().toString(),
                String.format("%.2f", getPaymentProcess().getGrossPay()),
                String.format("%.2f", getPaymentProcess().getPRSI()),
                String.format("%.2f", getPaymentProcess().getUSC()),
                String.format("%.2f", getPaymentProcess().getIncomeTax()),
                String.format("%.2f", getPaymentProcess().getHealthInsurance()),
                String.format("%.2f", getPaymentProcess().getUnionFees()),
                String.format("%.2f", getPaymentProcess().getNetPay()));
    }

    /**
     * Method to retrieve a payslip data by reading through an array list of csv files
     * and allowing the user to choose the one they wish to open.
     * @param userName this is the username of the employee
     * @throws IOException ensures an exception is thrown based on the users choice if it is invalid
     */
    public static void getPayslipData(String userName) throws IOException {
        //folder to hold the directory to the folder holding csv files
        String folder = "src/PaymentProcess/PayslipHistory/";
        FolderReader reader = new FolderReader(folder);
        //array list to hold the csv file names as strings
        ArrayList<String> payslipHistoryNames = reader.getFileNames();
        String userChoice = retrieveUserChoice(payslipHistoryNames);

        //instantiate a csv reader object to read the directory and the choice the user makes
        CSVReader csvReader = new CSVReader(folder + userChoice);
        //reads the data in the csv file the user chooses
        String payslipData = csvReader.findLine(userName,0);

        //conditional statements for if user is or is not found.
        if(payslipData != null){
            String[] data = payslipData.split(",");

            //string builder to print the payslip from the csv file as a structured string

            String payslipString = "======== PAYSLIP ======== \n\n" +
                    "|RECEIVER INFORMATION| \n\n" +
                    "FIRST NAME: " + data[1] + "\n" +
                    "LAST NAME: " + data[2] + "\n" +
                    "PPS NUMBER: " + data[3] + "\n" +
                    "EMPLOYEE ID: " + data[0] + "\n\n" +
                    "DATE OF PAYMENT: " + data[4] + "\n\n" +
                    "======= PAYMENT AND DEDUCTIONS ======== \n\n" +
                    "GROSS PAY: " + format("%.2f", Double.parseDouble(data[5])) + "\n" +
                    "PRSI: " + format("%.2f", Double.parseDouble(data[6])) + "\n" +
                    "USC: " + format("%.2f", Double.parseDouble(data[7])) + "\n" +
                    "INCOME TAX: " + format("%.2f", Double.parseDouble(data[8])) + "\n" +
                    "HEALTH INSURANCE: " + format("%.2f", Double.parseDouble(data[9])) + "\n" +
                    "UNION FEES: " + format("%.2f", Double.parseDouble(data[10])) + ("\n") +
                    "NET PAY: " + format("%.2f", Double.parseDouble(data[11])) + "\n";

            System.out.println(payslipString);
        }else{
            System.out.print("Employee data does not exist for this date in the payslip history. Please contact HR for further assistance");
        }
    }

    /**
     * Method to get the users choice and utilise it in the above method
     * @param payslipHistoryNames names of the csv files holding the payslip of each employee
     * @return returns a string
     */
    public static String retrieveUserChoice(ArrayList<String> payslipHistoryNames){
        Scanner in = new Scanner(System.in);

        //using aski values to use letters as the choice values in the command line for users
        char index = 'A';

        //for each string payslip csv file in payslipHistoryNames, print the index for
        //that payslip and allow the user to choose one of the options
        for(String payslip : payslipHistoryNames){
            System.out.println(index + ")" + payslip);
            index++;
        }
        System.out.println("Your choice: ");
        String userChoice = in.nextLine().trim().toUpperCase();

        if (userChoice.length() == 1) {
            int n = userChoice.charAt(0) - 'A';
            if (n >= 0 && n < payslipHistoryNames.size()) {
                return payslipHistoryNames.get(n);
            }
        }
        System.out.println("Invalid choice, please select a valid option");
        return null;
   }
}
