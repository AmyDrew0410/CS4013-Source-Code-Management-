package UserType;

public interface EmployeeHandler{

    public void addEmployee(UserTypes employee, Employees listOfEmployees);

    public void removeEmployee(UserTypes employee, Employees listOfEmployees);

}
