package Login;

import FileHandler.CSVReader;
import FileHandler.CSVWriter;
import FileHandler.FolderReader;
import Occupations.PromotionManager;
import PaymentProcess.PaymentCycleManager;
import PaymentProcess.Payslip;
import UserType.Employee;
import PaymentProcess.PayslipHistory;
import UserType.Employees;
import UserType.UserTypes;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class CLI
{
    private UserTypes employee;
    private final Employees employees = new Employees();
    private PaymentCycleManager manager ;
    private String requestingUser; // Store the user type (Admin, HR, Employee)
    private Logins logins = new Logins();
    private Scanner scanner;
    private PromotionManager promotionManager;
    private LocalDate currentDate = LocalDate.now();
    private int currentDay = currentDate.getDayOfMonth();
    private int currentMonth = currentDate.getMonthValue();
    private int currentYear = currentDate.getYear();
    //can now call methods from these classes

    private String username;
    private String password;
    //data fields

    public void login() throws IOException {
        //login method
        scanner = new Scanner(System.in);
        System.out.println("==========Login=============");
        System.out.println("Please enter your username: ");

        username = scanner.nextLine(); // Takes what user inputs as the username

        System.out.println("Please enter your password: ");
        password = scanner.nextLine(); // Takes what user inputs as the password



        if (logins.authenticateLogin(username, password)) {
            System.out.println("Welcome, " + username + "!");
            CLI();
        } else {
            logins.loginFailed();
        }
    }


    public void CLI() throws IOException {
        //in-app command line interface
        boolean run = true;
        requestingUser = logins.getRequestingUser();
        CSVWriter employeeWriter = new CSVWriter("src/UserType/resources/employees.csv");
        promotionManager = new PromotionManager(employeeWriter);

        // Now, use the user type that was retrieved from the getUserType method
        while (run) {
            if (requestingUser.equals("Admin")) {
                System.out.println("============================");
                System.out.println("What would you like to do?");
                System.out.println("============================");
                System.out.println("S)ee employee details   R)eview payslip history \nV)iew employee list " +
                        "    A)dd a new employee \nD)elete an employee     P)romote Employee \nT)ime Simulation \nG)et todays Date \nQ)uit");

                String command = scanner.nextLine().toUpperCase();

                // Handle commands for Admin
                if (command.equalsIgnoreCase("S")) {
                    System.out.println("Please enter the user ID of the employee who's details you wish to see if you wish to see your own type 0:");
                    int ID = scanner.nextInt();
                    scanner.nextLine(); // Consume newline

                    employee = null; // Reset before attempt
                    try {
                        if(ID>0) {
                            employee = employees.employeeInformation(ID);
                        } else {
                            employee = employees.employeeInformation(Integer.parseInt(username));
                        }
                    } catch(NullPointerException | NumberFormatException e) {
                        System.out.println("That employee Doesn't exist!");
                    }

                    // Only print if employee is not null
                    if (employee != null) {
                        System.out.println(employee.toString());
                    }
                } else if (command.equalsIgnoreCase("R"))
                {
                    System.out.println("Please enter the user ID of the employee who's details you wish to see if you wish to see your own type 0:");
                    String employeeID = scanner.next();
                    if(employeeID.equalsIgnoreCase("0"))
                    {
                        Payslip.getPayslipData(username);
                    }
                    else
                    {
                        Payslip.getPayslipData(employeeID);
                    }
                }
                else if (command.equalsIgnoreCase("V")) {
                    int count = 0;
                    for (UserTypes user : employees.getListOfEmployees()) // For every employee in the list of employees
                    {
                        count ++;
                        System.out.printf("***************** Employee %d :**********************\n",count);
                        System.out.println(user.toString()); // Print out the employee
                    }
                } else if (command.equalsIgnoreCase("A"))
                {
                    System.out.println("=====================");
                    System.out.println("Creating an Employee");
                    System.out.println("======================");

                    // Constructor for employee based off data
                    UserTypes employeeToAdd = newEmployee();
                    employees.addEmployee(employeeToAdd);

                } else if (command.equalsIgnoreCase("D")) {
                    System.out.println("=====================");
                    System.out.println("Deleting an Employee");
                    System.out.println("======================");
                    UserTypes employeeToKill = killEmployee();
                    if(employeeToKill != null){
                        employees.removeEmployee(employeeToKill);
                    }else{
                        System.out.println("The employee wasn't found!");
                    }
                }
                else if(command.equalsIgnoreCase("T"))
                {
                    System.out.println("================================================================");
                    System.out.println("Type 25 to set the current date to the next instance of the 25th");
                    System.out.println("Type year to set the current date to October 1st of the next year");
                    String choice = scanner.next();
                    dialationChoice(choice);
                }
                else if(command.equalsIgnoreCase("G"))
                {
                    System.out.printf("========== Todays Date : %s ========== \n",currentDate.toString());
                }
                else if (command.equalsIgnoreCase("Q"))
                {
                    run = false;
                }
            } else if (requestingUser.equals("HR")) {
                // Handle commands for HR
                System.out.println("============================");
                System.out.println("What would you like to do?");
                System.out.println("============================");
                System.out.println("S)ee employee details   R)eview payslip history \n" +
                        "A)dd a new employee    D)elete an employee\nP)romote Employee   T)ime Simulation\nG)et todays Date   Q)uit");


                String command = scanner.nextLine().toUpperCase();

                if (command.equalsIgnoreCase("S"))
                {
                    int ID = 0;
                    employee = null; // Reset before attempt
                    try {
                        employee = employees.employeeInformation(ID);
                    } catch(NullPointerException | NumberFormatException e) {
                        System.out.println("That employee Doesn't exist!");
                    }

                    // Only print if employee is not null
                    if (employee != null) {
                        System.out.println("======== Your Details =========");
                        System.out.println(employee.toString());
                    }
                }
                else if (command.equalsIgnoreCase("R"))
                {
                    System.out.println("Please enter the user ID of the employee who's details you wish to see if you wish to see your own type 0:");
                    String employeeID = scanner.next();
                    if(employeeID.equalsIgnoreCase("0"))
                    {
                        Payslip.getPayslipData(username);
                    }
                    else
                    {
                        Payslip.getPayslipData(employeeID);
                    }
                }
                else if (command.equalsIgnoreCase("V"))
                {
                    int count = 0;
                    for (UserTypes user : employees.getListOfEmployees()) // For every employee in the list of employees
                    {
                        count ++;
                        System.out.printf("***************** Employee %d :**********************\n",count);
                        System.out.println(user.toString()); // Print out the employee
                    }
                } else if (command.equalsIgnoreCase("A"))
                {
                    System.out.println("=====================");
                    System.out.println("Creating an Employee");
                    System.out.println("======================");

                    // Constructor for employee based off data
                    UserTypes employeeToAdd = newEmployee();
                    employees.addEmployee(employeeToAdd);

                } else if (command.equalsIgnoreCase("D")) {
                    System.out.println("=====================");
                    System.out.println("Deleting an Employee");
                    System.out.println("======================");
                    UserTypes employeeToKill = killEmployee();
                    if(employeeToKill != null){
                        employees.removeEmployee(employeeToKill);
                    }else{
                        System.out.println("The employee wasn't found!");
                    }
                } else if (command.equalsIgnoreCase("P"))
                {
                    System.out.println("Please enter the ID of the employee to be promoted to the next job title in the department");
                    int employeeID = scanner.nextInt();
                    promotionManager.manuallyPromoteEmployee(employeeID);

                }else if (command.equalsIgnoreCase("T")){
                    System.out.println("================================================================");
                    System.out.println("Type 25 to set the current date to the next instance of the 25th");
                    System.out.println("Type year to set the current date to October 1st of the next year");
                    String choice = scanner.next();
                    dialationChoice(choice);
                }else if (command.equalsIgnoreCase("G")){
                    System.out.printf("========== Todays Date : %s ========== \n",currentDate.toString());
                }else if(command.equalsIgnoreCase("Q")){
                    run = false;
                }
            } else if (requestingUser.equals("Employee")) {
                // Handle commands for Employee
                System.out.println("What would you like to do?");
                System.out.println("S)ee my details R)eview payslip history \n");

                String command = scanner.nextLine().toUpperCase();

                if (command.equals("S")) {
                    int ID = 0;
                    employee = null; // Reset before attempt
                    try {
                        employee = employees.employeeInformation(ID);
                    } catch(NullPointerException | NumberFormatException e) {
                        System.out.println("That employee Doesn't exist!");
                    }

                    // Only print if employee is not null
                    if (employee != null) {
                        System.out.println("======== Your Details =========");
                        System.out.println(employee.toString());
                    }
                } else if (command.equals("P")) {
                    Payslip.getPayslipData(username);
                }
            }


        }
        scanner.close();
    }

    public UserTypes newEmployee(){
        //First name
        System.out.println("Enter a first Name :");
        String name = scanner.nextLine();
        //Sur name
        System.out.println("Enter a surname : ");
        String surName = scanner.nextLine();
        // Employee ID
        System.out.println("Enter an EmployeeID : ");
        int employeeID = scanner.nextInt();
        // Email Address
        System.out.println("Enter an Email: ");
        String email = scanner.next();
        // Martial status
        System.out.println("Are they married? Y/N");
        boolean married = scanner.next().equalsIgnoreCase("Y");
        // Phone number
        System.out.println("Phone Number : ");
        String phoneNumber = scanner.next();
        // PPSN
        System.out.println("PPSN : ");
        String ppsn = scanner.next();
        // Union
        System.out.println("Are they a part of a union if so type A for UnionA and B for UnionB :");
        String union = scanner.next();

        return new Employee(name,surName,employeeID,phoneNumber,email,married,ppsn,union);
    }

    public UserTypes killEmployee()
    {

        System.out.println("Please enter the employee to be removed :");
        int employeeID = scanner.nextInt();
        for (UserTypes emp : employees.getListOfEmployees()) {
            if (emp.getEmployee_ID() == employeeID) {
                return emp;
            }
        }
        return null;
    }

    public void dialationChoice(String choice){
        if(choice.equalsIgnoreCase("25"))
        {
            timeDialateCycle();
        }else if(choice.equalsIgnoreCase("year")){
            timeDialateYear();
        }else{
            System.out.println("Incorrect input type Try Again");
        }
    }


    public void timeDialateCycle(){
        if(currentDay > 25)
        {
            currentMonth +=1;
            currentDay = 25;

        }else{
            currentDay = 25;
        }
        currentDate = LocalDate.of(currentYear,currentMonth,currentDay);
        try {
            String monthString;
            switch (currentMonth) {
                case 1:
                    monthString = "January";
                    break;
                case 2:
                    monthString = "February";
                    break;
                case 3:
                    monthString = "March";
                    break;
                case 4:
                    monthString = "April";
                    break;
                case 5:
                    monthString = "May";
                    break;
                case 6:
                    monthString = "June";
                    break;
                case 7:
                    monthString = "July";
                    break;
                case 8:
                    monthString = "August";
                    break;
                case 9:
                    monthString = "September";
                    break;
                case 10:
                    monthString = "October";
                    break;
                case 11:
                    monthString = "November";
                    break;
                case 12:
                    monthString = "December";
                    break;
                default:
                    monthString = "Invalid month";
                    break;
            }
            try {
                manager = new PaymentCycleManager();
                manager.processCycle(monthString, currentYear, currentDate);
            } catch (IOException e) {
                System.out.println("Tardis ran into an error returning to root time!");
            }
        } catch (Exception e) {
            System.out.println("An error occured exiting the time dialation!");
        }
    }

    public void timeDialateYear()
    {
        currentDate = LocalDate.of(currentYear+1,10,1);
        try
        {
            promotionManager.performYearlyUpgrade();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

}


