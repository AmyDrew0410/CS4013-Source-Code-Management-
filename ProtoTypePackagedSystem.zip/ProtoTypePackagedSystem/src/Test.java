import FileHandler.*;
import Occupations.PromotionManager;
import PaymentProcess.PaymentCycleManager;
import UserType.*;


import java.io.IOException;

import java.util.ArrayList;

public class Test
{
    public static void main(String[] args) throws IOException {
        CSVWriter writer = new CSVWriter("src/UserType/resources/employees.csv");
        PromotionManager manager = new PromotionManager(writer);
        manager.manuallyPromoteEmployee(23346152);

    }
}
