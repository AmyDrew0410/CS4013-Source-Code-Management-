package UserType;

import FileHandler.CSVWriter;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.InputMismatchException;

public class Admin extends UserTypes implements EmployeeHandler{

    
    public Admin(String first_Name, String last_Name, int employee_ID, String phone_Number, String email, Boolean marital_Status, String PPSN, String unionFees,String password){
        super(first_Name, last_Name, employee_ID, phone_Number, email, marital_Status, PPSN, "UserType.Admin", unionFees,password);
    }

    public Admin(String data){
        super(data);
    }

    @Override
    public boolean AccessEmployeeList(){
        return true;
    }
    
    @Override
    public void addEmployee(UserTypes employee, Employees listOfEmployees){
        if(listOfEmployees.equals(employee)){
            System.out.println("UserType.Employee already exists.");
        }else{
                listOfEmployees.add(employee);
        }
    }

    @Override
    public void removeEmployee(UserTypes employee, Employees listOfEmployees){
        // Remove the specified employee From the list
        listOfEmployees.remove(employee);
        try
        {
            CSVWriter writer = new CSVWriter("src/UserType/resources/employees.csv");
            ArrayList<UserTypes> empData = listOfEmployees.getListOfEmployees();
            ArrayList<String> toWrite = new ArrayList<>();
            for(UserTypes emp : empData)
            {
                toWrite.add(emp.toCSV());
            }
        }catch(IOException | InputMismatchException e)
        {
            if(e instanceof FileNotFoundException){
                System.err.println("The file Could Not be found! ");
            }else{
                System.err.println("The employee ID doesn't exist in this file");
            }
        }

    }


    @Override
    public String toString(){
        return super.toString();
    }


}