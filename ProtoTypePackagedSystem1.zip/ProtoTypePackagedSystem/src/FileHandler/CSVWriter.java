package FileHandler;

import java.io.*;
import java.nio.file.Path;
import java.util.ArrayList;

import static java.nio.file.Files.delete;

public class CSVWriter
{
    public final String pathName;
    public BufferedWriter writer;

    public CSVWriter(String pathName) throws IOException {
        this.pathName = pathName;
        try{
            writer = new BufferedWriter(new FileWriter(this.pathName));
        }catch(FileNotFoundException e){
            System.out.println("File not found! Generating the file");
            File file = new File(this.pathName);
            writer = new BufferedWriter(new FileWriter(file));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
    public CSVWriter(String pathToDirectory, String fileName) throws IOException {
        this.pathName = pathToDirectory + fileName;
        try{
            writer = new BufferedWriter(new FileWriter(this.pathName));
        }catch(FileNotFoundException e){
            System.out.println("File not found! Generating the file");
            File file = new File(fileName);
            writer = new BufferedWriter(new FileWriter(pathToDirectory + file));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void writeToCSV( ArrayList<String> toWrite) throws IOException {
        for (String s : toWrite) {
            writer.write(s);
            writer.newLine();
        }
        writer.close();
    }

    public void OverWriteData(ArrayList<String> toOverWrite)
    {
        //Create a new writer with the append Flag set to false
        try {
            writer = new BufferedWriter(new FileWriter(pathName,false));
            writeToCSV(toOverWrite);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
