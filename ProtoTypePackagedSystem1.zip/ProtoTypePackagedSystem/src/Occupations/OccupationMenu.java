package Occupations;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import FileHandler.*;

/**
 * Handles initialising an occupation object each time one is instantiated in our system
 * @author Ben Bastianelli StudentI.D. 23368071
 * @Version : 1.0
 */
public class OccupationMenu {
    private Scanner in;
    private static Map<String,Integer> ascensionCount = new HashMap<>();
    private static final int maxAscensionCount = 3;
    public OccupationMenu(){
        in = new Scanner(System.in);
    }

    public Occupation run(){
        //Ask the UserType.HR officer what department they wish to add the employee to
        System.out.println("What department is the employee being allocated to:");

        //Implement method to list all department options and returns user choice as string
        CSVReader departments = null;
        try {
            departments = new CSVReader("src/Occupations/resources/departments.csv");
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        ArrayList<String> departmentsToChoose = departments.readColFromCSV(0);
        String department = (String) choice(departmentsToChoose);

        //If our string equals a department, call the initOccupation method
        Occupation toReturn = initOccupation(department);
        return toReturn;
    }

    /**
     * Initialises our Occupations.Occupation Object for our Occupations.Occupation subClass
     * Reads data from our CSV to return a unique list of Choices
     * Returns the Choice they made and assigns it to the specified class Variable
     * in Occupations.Occupation types
     * @return Occupations.Occupation Object
     */
    private Occupation initOccupation(String department){
        try {
            //Create a csvHandler for the given departments csv file
            CSVReader chosenDepartment = new CSVReader("src/Occupations/resources/"+department+".csv");

            //List all jobTitle Choices
            ArrayList<String> jobTitles = chosenDepartment.readColFromCSV(1);

            //Make the user choose a job title
            String jobTitle = (String) choice(jobTitles);

            //From this use the SortByKey method to obtain a point value
            ArrayList<String> pointRange = chosenDepartment.sortByKey(jobTitle,2);
            String pointValue = (String) choice(pointRange);
            int pointValueParsed = Integer.parseInt(pointValue);

            //Create a string that represents the current tuple of our csv file
            String tuple = String.format("%s,%s,%s,",department,jobTitle,pointValue);

            //Finally use our findTuple method to set a salary.
            String tempSalary = chosenDepartment.tupleFind(tuple,3);

            //Our salary will be returned in the for "[EuroSign] 120,000" so we need to fix the format before
            //We parse it
            tempSalary = stringFixFormat(tempSalary);
            double salary = Double.parseDouble(tempSalary);

            //Remove all whitespace in our department name so it fits the Enum data-types
            department = department.replaceAll(" ", "");

            Occupation occupation = new Occupation(department,jobTitle,pointValueParsed,salary);
            return occupation;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static boolean checkAscend(String employeeID){
        // First check if the employee exists in the map
        if (!ascensionCount.containsKey(employeeID)) {
            return false; // Employee hasn't been promoted yet
        }

        // Now safely check if they've reached max ascensions
        return ascensionCount.get(employeeID) >= maxAscensionCount;
    }


    /**
     *
     */
    public String promote(String employeeID)
    {
        try {
            CSVReader reader = new CSVReader("src/UserType/resources/employees.csv");
            String empToBePromoted = reader.findLine(employeeID,2);
            System.out.println(empToBePromoted);

            String[] empSplit = empToBePromoted.split(",");

            //Read the occupations csv file for his dep and find the job title above it
            reader = new CSVReader("src/Occupations/resources/" + empSplit[7] + ".csv");
            ArrayList<String> allJobTitles = reader.readColFromCSV(1);
            String newJobTitle = "";
            for(int i = 0; i < allJobTitles.size(); i++){
                if (allJobTitles.get(i).contains(empSplit[8])){
                    newJobTitle = allJobTitles.get(i-1);
                    System.out.println(newJobTitle);
                }
            }

            // Construct the employees occupation based on the new Data
            if(!newJobTitle.isEmpty()){
                String tuple = String.format("%s,%s,%s,",empSplit[7],newJobTitle,"1");
                String newSalary = reader.tupleFind(tuple,3);
                //Add these values to split and reconstruct the employee
                empSplit[8] = newJobTitle;
                empSplit[9] = "1";
                empSplit[10] = newSalary;
            }

            String newEmpData = empSplit[0] + ",";
            for(String data : empSplit){
                newEmpData += data + ",";
            }

            return newEmpData;



        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
    /**
     * This method implements the point upgrade system for the Occupations.Occupation class
     * which allows for the upgrade of a users point in the salary scale
     * @throws IOException
     */
    public void yearlyUpgrade() throws IOException {
        //Create a List of every employees current Occupation status'
        CSVReader reader = new CSVReader("src/UserType/resources/employees.csv"); // A csvReader object that reads froms employees.csv
        ArrayList<String> employeeData = reader.readAllFromCSV(); // Returns every line of csv data in the file

        ArrayList<String> nonPromotedEmps = new ArrayList<>();
        for(String employee : employeeData)
        {
            String[] split = employee.split(","); // Split by commas
            if(checkAscend(split[2]))
            {
                employeeData.add(promote(employee));
            }
            else
            {
                nonPromotedEmps.add(employee);
            }

        }

        // Array List to store occupational Data
        ArrayList<String> employeeID = new ArrayList<>();
        ArrayList<String> DepartmentData = new ArrayList<>();
        ArrayList<String> JobTitleData = new ArrayList<>();
        ArrayList<String> currentPointData = new ArrayList<>();
        ArrayList<String> newSalaryData = new ArrayList<>();

        //Read Through and find the employees occupational data
        for(String employee : nonPromotedEmps)
        {
            String[] split = employee.split(",");
            employeeID.add(split[2]);
            DepartmentData.add(split[7]);
            JobTitleData.add(split[8]);
            currentPointData.add(split[9]);

        }

        // Parse the point data to integer increment it by 1 if it isn't at the top of its payscale
        setNewPoints(employeeID,DepartmentData,JobTitleData, currentPointData);

        // Find the new salaries
        int count = 0;
        for(String Department : DepartmentData){
            //Create strings for each tuple and find the new salaries
            String newEmployeeData = String.format("%s,%s,%s,",Department,JobTitleData.get(count),currentPointData.get(count));
            CSVReader csvReader = new CSVReader("src/Occupations/resources/" + DepartmentData.get(count) + ".csv");
            String nextSalary = stringFixFormat(csvReader.tupleFind(newEmployeeData,3));
            newSalaryData.add(nextSalary);
            count++;
        }
        // reconstruct the strings for reading back to employeedata
        reConstructEmployeeData(employeeData,JobTitleData,currentPointData,newSalaryData);

        //Finally call the employeeData Overwrite method and pass through the new arrayList
        CSVWriter writer = new CSVWriter("src/UserType/resources/employees.csv");

        try // Try catch to handle Exceptions
        {
            writer.OverWriteData(employeeData);
        } catch (Exception e) {
            System.out.println("Error while writing the file!");
        }
    }

    public void reConstructEmployeeData(ArrayList<String> employeeData, ArrayList<String> JobTitleData, ArrayList<String> currentPointData, ArrayList<String> newSalaryData) {
        for (int count = 0; count < employeeData.size(); count++) {
            String employee = employeeData.get(count); // Get the current employee data
            String[] split = employee.split(","); // Split the employee data into parts

            // Update the relevant fields with new data
            split[8] = JobTitleData.get(count);
            split[9] = currentPointData.get(count);
            split[10] = newSalaryData.get(count);

            // Reconstruct the updated employee data string
            StringBuilder newEmployee = new StringBuilder(split[0]);
            for (int i = 1; i < split.length; i++) {
                newEmployee.append(",").append(split[i]);
            }

            // Update the employee data in the list
            employeeData.set(count, newEmployee.toString());
        }
    }


    public void setNewPoints(ArrayList<String> employeeID,ArrayList<String> DepartmentData, ArrayList<String> JobTitleData, ArrayList<String> currentPointData) {
        for (int count = 0; count < currentPointData.size(); count++) {
            String currentPoints = currentPointData.get(count);
            String pathName = "src/Occupations/resources/" + DepartmentData.get(count) + ".csv";

            try {
                CSVReader occupationReader = new CSVReader(pathName);
                ArrayList<String> pointRange = occupationReader.sortByKey(JobTitleData.get(count), 2); // Gets every point
                String maxPointRange = String.valueOf(pointRange.size()); // The largest point is the size of the ArrayList

                if (!currentPoints.equals(maxPointRange))
                {
                    int newPoint = Integer.parseInt(currentPoints) + 1; // Parse the old Point to an int and add 1
                    currentPointData.set(count, String.valueOf(newPoint)); // Update the value directly by index
                }else if (ascensionCount.containsKey(employeeID.get(count))){
                    ascensionCount.replace(employeeID.get(count),ascensionCount.get(employeeID.get(count))+1);
                    if(ascensionCount.containsKey(employeeID.get(count))){
                        System.out.println(ascensionCount.get(employeeID.get(count)));
                    }

                }else{
                    ascensionCount.put(employeeID.get(count),1);
                    System.out.println("Employees been added to ascension count" + employeeID.get(count));
                }



            }
            catch (FileNotFoundException e)
            {
                System.err.println("File not found at path! " + pathName);
            }
        }
    }


    private String stringFixFormat(String target){
        target = target.replace("€", "");
        target = target.replaceAll("\"","");
        target = target.replace(",","");
        return target;
    }

    public Object choice(ArrayList<String> occupationTypes) {
        char index = 'A';
        for (Object occupation : occupationTypes) {
            System.out.printf("%s) %s \n", index, occupation);
            index++;
        }
        System.out.print("Your Choice: ");
        String userChoice = in.nextLine().trim().toUpperCase();

        // Check if input is a single letter within the expected range
        if (userChoice.length() == 1) {
            int n = userChoice.charAt(0) - 'A';
            if (n >= 0 && n < occupationTypes.size()) {
                return occupationTypes.get(n);
            }
        }
        System.out.println("Invalid choice. Please select a valid option.");
        return null;
    }

}
