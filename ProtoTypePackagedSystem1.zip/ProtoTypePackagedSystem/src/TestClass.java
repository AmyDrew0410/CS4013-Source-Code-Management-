import FileHandler.CSVReader;
import FileHandler.CSVWriter;
import Occupations.Occupation;
import Occupations.OccupationMenu;
import UserType.*;
import PaymentProcess.*;
import Login.Login;
import Login.Logins;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class TestClass {
    public static void main(String[] args) throws IOException {
        Logins loginAttempt = new Logins();

        loginAttempt.authenticateLogin("23368071","BananaFish32");



    }
}
